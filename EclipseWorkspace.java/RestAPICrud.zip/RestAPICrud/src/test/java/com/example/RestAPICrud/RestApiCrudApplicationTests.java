package com.example.RestAPICrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestApiCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
