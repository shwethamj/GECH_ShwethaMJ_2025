package com.example.DBRelationEmployee.DTO;

public class AddressDTO {
	
	private String address;

	public AddressDTO(String address) {
		super();
		this.address = address;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public AddressDTO() {
		super();
	}

	
	
}
