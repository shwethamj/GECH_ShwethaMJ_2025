package com.example.DBRelationEmployee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbRelationEmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
