package com.example.DBRelationEmployee;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbRelationEmployeeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DbRelationEmployeeApplication.class, args);
	}
}